-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2014 at 03:31 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE IF NOT EXISTS `attributes` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_code` varchar(255) NOT NULL,
  `attribute_default_value` text NOT NULL,
  `attribute_type` enum('number','text','date','select','multiselect') NOT NULL,
  `attribute_requires_editor` enum('0','1') NOT NULL,
  `attribute_admin_label` varchar(255) NOT NULL,
  `attribute_frontend_label` varchar(255) NOT NULL,
  `is_unique` enum('0','1') NOT NULL,
  `is_required` enum('0','1') NOT NULL,
  `is_used_for_variation` enum('0','1') NOT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_code` (`attribute_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`attribute_id`, `attribute_code`, `attribute_default_value`, `attribute_type`, `attribute_requires_editor`, `attribute_admin_label`, `attribute_frontend_label`, `is_unique`, `is_required`, `is_used_for_variation`) VALUES
(16, 'weight', '0', 'select', '0', 'Weight', 'Weight', '0', '1', ''),
(18, 'test', 'test', 'select', '0', 'test', 'test', '0', '0', '0'),
(25, 'rabbit_gender', '', 'select', '0', 'Gender', 'Gender', '0', '0', '0'),
(26, 'rabbit_product_group', '', 'select', '0', 'Group', 'Group', '0', '0', '0'),
(27, 'rabbit_family_id', '', 'number', '0', 'Family ID', 'Family ID', '0', '0', '0'),
(28, 'rabbit_dob', '', 'date', '0', 'DOB', 'DOB', '0', '0', '0'),
(29, 'rabbit_latest_mate_date', '', 'date', '0', 'Mated Date', 'Mated Date', '0', '0', '0'),
(30, 'rabbit_latest_pregnant_date', '', 'date', '0', 'Pregnant Date', 'Pregnant Date', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_attributeset`
--

CREATE TABLE IF NOT EXISTS `attribute_attributeset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`attribute_set_id`),
  KEY `attribute_set_id` (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `attribute_attributeset`
--

INSERT INTO `attribute_attributeset` (`id`, `attribute_id`, `attribute_set_id`, `sort_order`) VALUES
(9, 25, 4, 0),
(10, 26, 4, 1),
(11, 27, 4, 2),
(12, 28, 4, 3),
(13, 29, 4, 4),
(14, 30, 4, 5),
(15, 16, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_sets`
--

CREATE TABLE IF NOT EXISTS `attribute_sets` (
  `attribute_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_set_code` varchar(255) NOT NULL,
  `attribute_set_name` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `attribute_sets`
--

INSERT INTO `attribute_sets` (`attribute_set_id`, `attribute_set_code`, `attribute_set_name`, `sort_order`) VALUES
(4, 'rabbit', 'Rabbit', 0),
(5, 'feed', 'Feed', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

CREATE TABLE IF NOT EXISTS `attribute_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`id`, `attribute_id`, `value`, `sort_order`) VALUES
(7, 16, '300', 2),
(8, 16, '400', 1),
(9, 18, 'sadf', 1),
(10, 18, 'asdf', 2),
(11, 25, 'Male', 0),
(12, 25, 'Female', 1),
(13, 26, 'Parents', 0),
(14, 26, 'Kittens', 1),
(15, 26, 'Parents to be', 2),
(16, 26, 'Parents to sell', 3),
(17, 26, 'Products', 4);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_display_name` varchar(255) NOT NULL,
  `category_description` text NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_root` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_code`, `category_name`, `category_display_name`, `category_description`, `parent_id`, `is_root`, `sort_order`) VALUES
(2, 'food', 'Food', 'Food', 'Food for rabbits', 0, '1', 0),
(3, 'feed', 'Feed', 'Feed', 'Feed for rabbits', 2, '0', 0),
(4, 'rabbits', 'Rabbits', 'Rabbits', '', 0, '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products_inventory`
--

CREATE TABLE IF NOT EXISTS `products_inventory` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sku` varchar(255) NOT NULL,
  `daily_use_status` enum('0','1') NOT NULL DEFAULT '0',
  `daily_use_quantity` double DEFAULT NULL,
  `product_quantity` double NOT NULL,
  `in_stock` enum('0','1') NOT NULL,
  `unit_price` double NOT NULL,
  `status` enum('0','1') NOT NULL,
  `is_variation` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_type` enum('in','out') NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_type_id` (`product_type_id`,`attribute_set_id`),
  KEY `attribute_set_id` (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `products_inventory`
--

INSERT INTO `products_inventory` (`product_id`, `product_type_id`, `attribute_set_id`, `product_name`, `product_sku`, `daily_use_status`, `daily_use_quantity`, `product_quantity`, `in_stock`, `unit_price`, `status`, `is_variation`, `sort_order`, `created_date`, `updated_date`, `product_type`) VALUES
(11, 1, 4, 'Rabbit 1', 'rabbit_1', '0', NULL, 1, '0', 100, '1', '0', 0, '2014-12-02 18:15:00', '2014-12-02 18:15:00', 'in'),
(12, 1, 4, 'Rabbit 2', 'rabbit_2', '0', NULL, 1, '1', 100, '1', '0', 0, '2014-12-02 18:15:00', '2014-12-02 18:15:00', 'in'),
(13, 1, 4, 'Rabbit 3', 'rabbit_3', '0', NULL, 1, '1', 100, '1', '0', 0, '2014-12-02 18:15:00', '2014-12-03 05:51:00', 'in'),
(14, 1, 4, 'Rabbit 4', 'rabbit_4', '0', NULL, 100, '1', 101, '1', '0', 0, '2014-12-06 18:15:00', '2014-12-06 18:15:00', 'in'),
(15, 1, 4, 'Rabbit 5', 'rabbit_5', '0', NULL, 1, '1', 100, '1', '0', 0, '2014-12-06 18:15:00', '2014-12-06 18:15:00', 'in'),
(16, 1, 5, 'Grass', 'grass', '1', 10, 50, '0', 10, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-08 14:31:15', 'in'),
(17, 1, 5, 'Hay', 'hay', '1', 10, 50, '1', 101, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-08 14:31:15', 'in'),
(18, 1, 4, 'test', 'test123', '1', 19, 1904, '1', 100, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-08 14:31:15', 'in'),
(19, 1, 5, 'Combo', 'combo', '0', 0, 90, '1', 200, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-07 18:15:00', 'in');

-- --------------------------------------------------------

--
-- Table structure for table `products_type`
--

CREATE TABLE IF NOT EXISTS `products_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_code` varchar(255) NOT NULL,
  `product_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_type_code` (`product_type_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `products_type`
--

INSERT INTO `products_type` (`id`, `product_type_code`, `product_type_name`) VALUES
(1, 'simple', 'Simple');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_date`
--

CREATE TABLE IF NOT EXISTS `product_attribute_value_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` date NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `product_attribute_value_date`
--

INSERT INTO `product_attribute_value_date` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 23, 6, '2014-12-03', '0000-00-00'),
(2, 23, 7, '2014-12-10', '0000-00-00'),
(3, 23, 8, '2014-12-10', '0000-00-00'),
(4, 28, 11, '2014-12-03', '2014-12-03'),
(5, 29, 11, '0000-00-00', '2014-12-03'),
(6, 30, 11, '0000-00-00', '2014-12-03'),
(7, 28, 12, '2014-12-03', '2014-12-03'),
(8, 29, 12, '0000-00-00', '2014-12-03'),
(9, 30, 12, '0000-00-00', '2014-12-03'),
(10, 28, 13, '2014-12-03', '2014-12-03'),
(11, 29, 13, '0000-00-00', '2014-12-03'),
(12, 30, 13, '0000-00-00', '2014-12-03'),
(13, 28, 14, '2014-12-03', '2014-12-07'),
(14, 29, 14, '0000-00-00', '2014-12-07'),
(15, 30, 14, '0000-00-00', '2014-12-07'),
(16, 28, 15, '2014-12-03', '2014-12-07'),
(17, 29, 15, '0000-00-00', '2014-12-07'),
(18, 30, 15, '0000-00-00', '2014-12-07'),
(19, 28, 18, '2014-12-09', '2014-12-08'),
(20, 29, 18, '0000-00-00', '2014-12-08'),
(21, 30, 18, '0000-00-00', '2014-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_number`
--

CREATE TABLE IF NOT EXISTS `product_attribute_value_number` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product_attribute_value_number`
--

INSERT INTO `product_attribute_value_number` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 27, 11, 1, '2014-12-03'),
(2, 27, 12, 1, '2014-12-03'),
(3, 27, 13, 1, '2014-12-03'),
(4, 27, 14, 1, '2014-12-07'),
(5, 27, 15, 2, '2014-12-07'),
(6, 27, 18, 2, '2014-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_option`
--

CREATE TABLE IF NOT EXISTS `product_attribute_value_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`),
  KEY `product_id` (`product_id`),
  KEY `value_id` (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `product_attribute_value_option`
--

INSERT INTO `product_attribute_value_option` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 16, 3, 8, '0000-00-00'),
(2, 16, 4, 7, '0000-00-00'),
(3, 16, 5, 8, '0000-00-00'),
(4, 16, 6, 8, '0000-00-00'),
(5, 16, 7, 8, '0000-00-00'),
(6, 16, 8, 8, '0000-00-00'),
(7, 25, 11, 11, '2014-12-03'),
(8, 26, 11, 13, '2014-12-03'),
(9, 25, 12, 12, '2014-12-03'),
(10, 26, 12, 13, '2014-12-03'),
(11, 25, 13, 11, '2014-12-03'),
(12, 26, 13, 13, '2014-12-03'),
(13, 25, 14, 11, '2014-12-07'),
(14, 26, 14, 13, '2014-12-07'),
(15, 25, 15, 11, '2014-12-07'),
(16, 26, 15, 13, '2014-12-07'),
(17, 16, 16, 7, '2014-12-08'),
(18, 16, 17, 8, '2014-12-08'),
(19, 25, 18, 11, '2014-12-08'),
(20, 26, 18, 13, '2014-12-08'),
(21, 16, 19, 8, '2014-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_text`
--

CREATE TABLE IF NOT EXISTS `product_attribute_value_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE IF NOT EXISTS `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id`, `product_id`, `category_id`, `sort_order`) VALUES
(1, 3, 2, 0),
(2, 3, 3, 0),
(3, 4, 2, 0),
(4, 5, 2, 0),
(5, 5, 3, 0),
(6, 6, 2, 0),
(7, 6, 3, 0),
(8, 7, 2, 0),
(9, 7, 3, 0),
(10, 8, 3, 0),
(11, 11, 4, 0),
(12, 12, 4, 0),
(13, 13, 4, 0),
(14, 14, 4, 0),
(21, 15, 4, 0),
(25, 17, 3, 0),
(28, 18, 4, 0),
(30, 16, 3, 0),
(32, 19, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder_product`
--

CREATE TABLE IF NOT EXISTS `purchaseorder_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unit_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_id` (`purchase_order_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `purchaseorder_product`
--

INSERT INTO `purchaseorder_product` (`id`, `purchase_order_id`, `product_id`, `unit_price`, `quantity`, `total_price`) VALUES
(5, 6, 3, 20, 20, 400),
(6, 6, 4, 21.25, 20, 425),
(7, 7, 4, 20, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `purchase_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `purchase_order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purchase_order_recieve_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `purchase_order_assigned_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`purchase_order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`purchase_order_id`, `employee_id`, `purchase_order_date`, `purchase_order_recieve_date`, `purchase_order_assigned_date`) VALUES
(6, 0, '2014-11-28 18:15:00', '2014-11-28 18:15:00', '2014-11-28 18:15:00'),
(7, 0, '2014-11-29 18:15:00', '2014-11-29 18:15:00', '2014-11-29 18:15:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attribute_attributeset`
--
ALTER TABLE `attribute_attributeset`
  ADD CONSTRAINT `attribute_attributeset_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `attribute_attributeset_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD CONSTRAINT `attribute_values_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products_inventory`
--
ALTER TABLE `products_inventory`
  ADD CONSTRAINT `products_inventory_ibfk_1` FOREIGN KEY (`product_type_id`) REFERENCES `products_type` (`id`),
  ADD CONSTRAINT `products_inventory_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`);

--
-- Constraints for table `product_attribute_value_number`
--
ALTER TABLE `product_attribute_value_number`
  ADD CONSTRAINT `product_attribute_value_number_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_number_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_attribute_value_option`
--
ALTER TABLE `product_attribute_value_option`
  ADD CONSTRAINT `product_attribute_value_option_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_option_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_option_ibfk_3` FOREIGN KEY (`value`) REFERENCES `attribute_values` (`id`);

--
-- Constraints for table `product_attribute_value_text`
--
ALTER TABLE `product_attribute_value_text`
  ADD CONSTRAINT `product_attribute_value_text_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_text_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_category`
--
ALTER TABLE `product_category`
  ADD CONSTRAINT `product_category_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchaseorder_product`
--
ALTER TABLE `purchaseorder_product`
  ADD CONSTRAINT `purchaseorder_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`),
  ADD CONSTRAINT `purchaseorder_product_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`purchase_order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
