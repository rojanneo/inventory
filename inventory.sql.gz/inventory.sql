-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2014 at 02:53 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `aa_family`
--

DROP TABLE IF EXISTS `aa_family`;
CREATE TABLE IF NOT EXISTS `aa_family` (
  `f_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_DT` date NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `aa_family`
--

INSERT INTO `aa_family` (`f_id`, `created_DT`) VALUES
(1, '2014-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `aa_family_to_be`
--

DROP TABLE IF EXISTS `aa_family_to_be`;
CREATE TABLE IF NOT EXISTS `aa_family_to_be` (
  `buck_r_id` bigint(20) NOT NULL,
  `doe_r_id` bigint(20) NOT NULL,
  `ID` bigint(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `aa_family_to_be`
--

INSERT INTO `aa_family_to_be` (`buck_r_id`, `doe_r_id`, `ID`) VALUES
(57, 46, 1),
(57, 49, 2),
(57, 50, 3),
(57, 51, 4),
(57, 53, 5),
(57, 55, 6),
(57, 56, 7),
(57, 57, 8),
(58, 46, 9),
(58, 49, 10),
(58, 50, 11),
(58, 51, 12),
(58, 53, 13),
(58, 55, 14),
(58, 56, 15),
(58, 57, 16),
(58, 58, 17),
(59, 46, 18),
(59, 49, 19),
(59, 50, 20),
(59, 51, 21),
(59, 53, 22),
(59, 55, 23),
(59, 56, 24),
(59, 57, 25),
(59, 58, 26),
(59, 59, 27),
(60, 46, 28),
(60, 49, 29),
(60, 50, 30),
(60, 51, 31),
(60, 53, 32),
(60, 55, 33),
(60, 56, 34),
(60, 57, 35),
(60, 58, 36),
(60, 59, 37),
(60, 60, 38),
(61, 46, 39),
(61, 49, 40),
(61, 50, 41),
(61, 51, 42),
(61, 53, 43),
(61, 55, 44),
(61, 56, 45),
(61, 57, 46),
(61, 58, 47),
(61, 59, 48),
(61, 60, 49),
(61, 61, 50);

-- --------------------------------------------------------

--
-- Table structure for table `aa_litter`
--

DROP TABLE IF EXISTS `aa_litter`;
CREATE TABLE IF NOT EXISTS `aa_litter` (
  `l_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `f_id` bigint(20) NOT NULL,
  `DOB` date NOT NULL,
  `does_no` bigint(20) NOT NULL,
  `bucks_no` bigint(20) NOT NULL,
  PRIMARY KEY (`l_id`),
  KEY `f_id` (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `aa_litter`
--

INSERT INTO `aa_litter` (`l_id`, `f_id`, `DOB`, `does_no`, `bucks_no`) VALUES
(1, 1, '2014-12-30', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `aa_rabbits`
--

DROP TABLE IF EXISTS `aa_rabbits`;
CREATE TABLE IF NOT EXISTS `aa_rabbits` (
  `r_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` enum('B','D') NOT NULL,
  `l_id` bigint(20) DEFAULT NULL,
  `f_id` bigint(20) DEFAULT NULL,
  `does_id` bigint(20) DEFAULT NULL,
  `buck_id` bigint(20) DEFAULT NULL,
  `last_given_birth` date DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `rabbit_slug` varchar(100) NOT NULL,
  PRIMARY KEY (`r_id`),
  UNIQUE KEY `rabbit_slug` (`rabbit_slug`),
  KEY `l_id` (`l_id`,`f_id`),
  KEY `f_id` (`f_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `aa_rabbits`
--

INSERT INTO `aa_rabbits` (`r_id`, `type`, `l_id`, `f_id`, `does_id`, `buck_id`, `last_given_birth`, `status`, `rabbit_slug`) VALUES
(58, 'D', NULL, 1, 0, 0, NULL, '1', 'f01_r01'),
(59, 'D', NULL, 1, 0, 0, NULL, '0', 'f01_r02'),
(60, 'D', NULL, 1, 0, 0, NULL, '0', 'f01_r03'),
(61, 'D', NULL, 1, 0, 0, NULL, '1', 'f01_r04');

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
CREATE TABLE IF NOT EXISTS `attributes` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_code` varchar(255) NOT NULL,
  `attribute_default_value` text NOT NULL,
  `attribute_type` enum('number','text','date','select','multiselect') NOT NULL,
  `attribute_requires_editor` enum('0','1') NOT NULL,
  `attribute_admin_label` varchar(255) NOT NULL,
  `attribute_frontend_label` varchar(255) NOT NULL,
  `is_unique` enum('0','1') NOT NULL,
  `is_required` enum('0','1') NOT NULL,
  `is_used_for_variation` enum('0','1') NOT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_code` (`attribute_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`attribute_id`, `attribute_code`, `attribute_default_value`, `attribute_type`, `attribute_requires_editor`, `attribute_admin_label`, `attribute_frontend_label`, `is_unique`, `is_required`, `is_used_for_variation`) VALUES
(16, 'weight', '0', 'select', '0', 'Weight', 'Weight', '0', '1', ''),
(18, 'test', 'test', 'select', '0', 'test', 'test', '0', '0', '0'),
(25, 'rabbit_gender', '', 'select', '0', 'Gender', 'Gender', '0', '0', ''),
(27, 'rabbit_family_id', '', 'number', '0', 'Family ID', 'Family ID', '0', '0', '0'),
(28, 'rabbit_dob', '', 'date', '0', 'DOB', 'DOB', '0', '0', '0'),
(29, 'rabbit_latest_mate_date', '', 'date', '0', 'Mated Date', 'Mated Date', '0', '0', '0'),
(30, 'rabbit_latest_pregnant_date', '', 'date', '0', 'Pregnant Date', 'Pregnant Date', '0', '0', '0'),
(31, 'rabbit_latest_birth_date', '0000-00-00', 'date', '0', 'Latest Birth Date', 'Latest Birth Date', '0', '0', ''),
(33, 'litters_born', '', 'number', '0', 'Litters Born', 'Litters Born', '0', '0', '0'),
(34, 'rabbit_latest_weaning_date', '', 'date', '0', 'Latest Weaning Date', 'Latest Weaning Date', '0', '0', '0'),
(35, 'rabbit_latest_culling_date', '', 'date', '0', 'Latest Culling Date', 'Latest Culling Date', '0', '0', '0'),
(36, 'parent_id', '', 'number', '0', 'Parent Rabbit', 'Parent Rabbit', '0', '1', '0'),
(37, 'is_pregnant', '', 'select', '0', 'Is Pregnant', 'Is Pregnant', '0', '0', '0'),
(38, 'is_matured', '', 'select', '0', 'Matured', 'Matured', '0', '1', '0'),
(39, 'rabbit_group', '', 'select', '0', 'Rabbit Group', 'Rabbit Group', '0', '1', '0'),
(40, 'recently_mated_buck', '0', 'number', '0', 'Recently Mated Buck', 'Recently Mated Buck', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_attributeset`
--

DROP TABLE IF EXISTS `attribute_attributeset`;
CREATE TABLE IF NOT EXISTS `attribute_attributeset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`attribute_set_id`),
  KEY `attribute_set_id` (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `attribute_attributeset`
--

INSERT INTO `attribute_attributeset` (`id`, `attribute_id`, `attribute_set_id`, `sort_order`) VALUES
(9, 25, 4, 0),
(11, 27, 4, 2),
(12, 28, 4, 3),
(13, 29, 4, 4),
(14, 30, 4, 5),
(15, 16, 5, 0),
(16, 31, 4, 6),
(18, 33, 4, 8),
(19, 34, 4, 9),
(20, 35, 4, 10),
(21, 27, 6, 0),
(22, 36, 6, 1),
(23, 36, 4, 11),
(24, 38, 4, 11),
(25, 39, 4, 11),
(26, 40, 4, 12);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_sets`
--

DROP TABLE IF EXISTS `attribute_sets`;
CREATE TABLE IF NOT EXISTS `attribute_sets` (
  `attribute_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_set_code` varchar(255) NOT NULL,
  `attribute_set_name` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `attribute_sets`
--

INSERT INTO `attribute_sets` (`attribute_set_id`, `attribute_set_code`, `attribute_set_name`, `sort_order`) VALUES
(4, 'rabbit', 'Rabbit', 0),
(5, 'feed', 'Feed', 1),
(6, 'litters', 'Litters', 2);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

DROP TABLE IF EXISTS `attribute_values`;
CREATE TABLE IF NOT EXISTS `attribute_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`id`, `attribute_id`, `value`, `sort_order`) VALUES
(11, 25, 'Male', 0),
(12, 25, 'Female', 1),
(13, 25, 'Litter', 2),
(14, 37, 'No', 0),
(15, 37, 'Yes', 1),
(16, 38, 'No', 0),
(17, 38, 'Yes', 1),
(18, 39, 'Parents', 0),
(19, 39, 'Parents to be', 1),
(20, 39, 'Products', 2),
(21, 39, 'Products to be ', 3);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_display_name` varchar(255) NOT NULL,
  `category_description` text NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_root` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_code`, `category_name`, `category_display_name`, `category_description`, `parent_id`, `is_root`, `sort_order`) VALUES
(2, 'food', 'Food', 'Food', 'Food for rabbits', 0, '1', 0),
(3, 'feed', 'Feed', 'Feed', 'Feed for rabbits', 2, '0', 0),
(4, 'rabbits', 'Rabbits', 'Rabbits', '', 0, '0', 0),
(5, 'litters', 'Litters', 'Litters', '', 0, '0', 3);

-- --------------------------------------------------------

--
-- Table structure for table `products_inventory`
--

DROP TABLE IF EXISTS `products_inventory`;
CREATE TABLE IF NOT EXISTS `products_inventory` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sku` varchar(255) NOT NULL,
  `parent_doe_id` int(11) DEFAULT NULL,
  `parent_buck_id` int(11) DEFAULT NULL,
  `daily_use_status` enum('0','1') NOT NULL DEFAULT '0',
  `daily_use_quantity` double DEFAULT NULL,
  `product_quantity` double NOT NULL,
  `in_stock` enum('0','1') NOT NULL,
  `unit_price` double NOT NULL,
  `status` enum('0','1') NOT NULL,
  `is_variation` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_type` enum('in','out') NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_type_id` (`product_type_id`,`attribute_set_id`),
  KEY `attribute_set_id` (`attribute_set_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `products_inventory`
--

INSERT INTO `products_inventory` (`product_id`, `product_type_id`, `attribute_set_id`, `product_name`, `product_sku`, `parent_doe_id`, `parent_buck_id`, `daily_use_status`, `daily_use_quantity`, `product_quantity`, `in_stock`, `unit_price`, `status`, `is_variation`, `sort_order`, `created_date`, `updated_date`, `product_type`) VALUES
(16, 1, 5, 'Grass', 'grass', NULL, NULL, '1', 10, 40, '0', 10, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-09 04:49:30', 'in'),
(19, 1, 5, 'Combo', 'combo', NULL, NULL, '0', 0, 90, '1', 200, '1', '0', 0, '2014-12-07 18:15:00', '2014-12-07 18:15:00', 'in'),
(58, 1, 4, 'F01R01', 'f01_r01', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2014-12-29 18:15:00', '2014-12-29 18:15:00', 'out'),
(59, 1, 4, 'F01R02', 'f01_r02', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2014-12-29 18:15:00', '2014-12-29 18:15:00', 'out'),
(60, 1, 4, 'F01R03', 'f01_r03', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2014-12-29 18:15:00', '2014-12-29 18:15:00', 'out'),
(61, 1, 4, 'F01R04', 'f01_r04', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2014-12-29 18:15:00', '2014-12-29 18:15:00', 'out');

-- --------------------------------------------------------

--
-- Table structure for table `products_type`
--

DROP TABLE IF EXISTS `products_type`;
CREATE TABLE IF NOT EXISTS `products_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type_code` varchar(255) NOT NULL,
  `product_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_type_code` (`product_type_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `products_type`
--

INSERT INTO `products_type` (`id`, `product_type_code`, `product_type_name`) VALUES
(1, 'simple', 'Simple');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_date`
--

DROP TABLE IF EXISTS `product_attribute_value_date`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` date NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `product_attribute_value_date`
--

INSERT INTO `product_attribute_value_date` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 28, 58, '2014-12-30', '2014-12-30'),
(2, 29, 58, '2014-12-30', '2014-12-30'),
(3, 30, 58, '0000-00-00', '2014-12-30'),
(4, 31, 58, '0000-00-00', '2014-12-30'),
(5, 34, 58, '0000-00-00', '2014-12-30'),
(6, 35, 58, '0000-00-00', '2014-12-30'),
(7, 28, 59, '2014-12-30', '2014-12-30'),
(8, 29, 59, '2014-12-18', '2014-12-30'),
(9, 30, 59, '2014-12-30', '2014-12-30'),
(10, 31, 59, '0000-00-00', '2014-12-30'),
(11, 34, 59, '0000-00-00', '2014-12-30'),
(12, 35, 59, '0000-00-00', '2014-12-30'),
(13, 28, 60, '2014-12-30', '2014-12-30'),
(14, 29, 60, '2014-12-18', '2014-12-30'),
(15, 30, 60, '2014-12-03', '2014-12-30'),
(16, 31, 60, '2014-12-30', '2014-12-30'),
(17, 34, 60, '0000-00-00', '2014-12-30'),
(18, 35, 60, '0000-00-00', '2014-12-30'),
(19, 28, 61, '2014-12-30', '2014-12-30'),
(20, 29, 61, '0000-00-00', '2014-12-30'),
(21, 30, 61, '0000-00-00', '2014-12-30'),
(22, 31, 61, '0000-00-00', '2014-12-30'),
(23, 34, 61, '0000-00-00', '2014-12-30'),
(24, 35, 61, '0000-00-00', '2014-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_number`
--

DROP TABLE IF EXISTS `product_attribute_value_number`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_number` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=142 ;

--
-- Dumping data for table `product_attribute_value_number`
--

INSERT INTO `product_attribute_value_number` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 27, 11, 1, '2014-12-30'),
(2, 27, 12, 1, '2014-12-30'),
(3, 27, 13, 1, '2014-12-30'),
(4, 27, 14, 1, '2014-12-30'),
(5, 27, 15, 2, '2014-12-30'),
(6, 27, 18, 2, '2014-12-30'),
(7, 27, 20, 2, '2014-12-30'),
(8, 27, 21, 3, '2014-12-27'),
(9, 27, 21, 2, '2014-12-28'),
(10, 33, 21, 0, '2014-12-28'),
(11, 27, 21, 2, '2014-12-28'),
(12, 33, 21, 0, '2014-12-28'),
(13, 27, 22, 2, '2014-12-28'),
(14, 36, 22, 18, '2014-12-28'),
(15, 27, 23, 2, '2014-12-28'),
(16, 36, 23, 18, '2014-12-28'),
(17, 27, 24, 2, '2014-12-28'),
(18, 33, 24, 0, '2014-12-28'),
(19, 27, 25, 2, '2014-12-28'),
(20, 33, 25, 0, '2014-12-28'),
(21, 27, 26, 2, '2014-12-28'),
(22, 33, 26, 0, '2014-12-28'),
(23, 27, 27, 2, '2014-12-28'),
(24, 33, 27, 0, '2014-12-28'),
(25, 27, 28, 3, '2014-12-30'),
(26, 33, 28, 0, '2014-12-30'),
(27, 36, 28, 0, '2014-12-30'),
(28, 27, 29, 3, '2014-12-30'),
(29, 33, 29, 0, '2014-12-30'),
(30, 36, 29, 0, '2014-12-30'),
(31, 27, 30, 3, '2014-12-30'),
(32, 33, 30, 0, '2014-12-30'),
(33, 36, 30, 0, '2014-12-30'),
(34, 27, 31, 3, '2014-12-30'),
(35, 33, 31, 0, '2014-12-30'),
(36, 36, 31, 0, '2014-12-30'),
(37, 27, 32, 3, '2014-12-29'),
(38, 33, 32, 0, '2014-12-29'),
(39, 36, 32, 29, '2014-12-29'),
(40, 27, 33, 3, '2014-12-29'),
(41, 33, 33, 0, '2014-12-29'),
(42, 36, 33, 29, '2014-12-29'),
(43, 27, 34, 3, '2014-12-29'),
(44, 33, 34, 0, '2014-12-29'),
(45, 36, 34, 30, '2014-12-29'),
(46, 33, 11, 0, '2014-12-30'),
(47, 36, 11, 0, '2014-12-30'),
(48, 33, 20, 0, '2014-12-30'),
(49, 36, 20, 0, '2014-12-30'),
(50, 33, 18, 0, '2014-12-30'),
(51, 36, 18, 0, '2014-12-30'),
(52, 33, 15, 0, '2014-12-30'),
(53, 36, 15, 0, '2014-12-30'),
(54, 33, 14, 0, '2014-12-30'),
(55, 36, 14, 0, '2014-12-30'),
(56, 33, 13, 0, '2014-12-30'),
(57, 36, 13, 0, '2014-12-30'),
(58, 33, 12, 0, '2014-12-30'),
(59, 36, 12, 0, '2014-12-30'),
(60, 27, 35, 3, '2014-12-30'),
(61, 33, 35, 0, '2014-12-30'),
(62, 36, 35, 29, '2014-12-30'),
(63, 27, 36, 3, '2014-12-30'),
(64, 33, 36, 0, '2014-12-30'),
(65, 36, 36, 29, '2014-12-30'),
(66, 27, 37, 4, '2014-12-30'),
(67, 33, 37, 0, '2014-12-30'),
(68, 36, 37, 0, '2014-12-30'),
(69, 27, 38, 4, '2014-12-30'),
(70, 33, 38, 0, '2014-12-30'),
(71, 36, 38, 0, '2014-12-30'),
(72, 27, 39, 4, '2014-12-30'),
(73, 33, 39, 0, '2014-12-30'),
(74, 36, 39, 0, '2014-12-30'),
(75, 27, 40, 4, '2014-12-30'),
(76, 33, 40, 0, '2014-12-30'),
(77, 36, 40, 0, '2014-12-30'),
(78, 27, 41, 5, '2014-12-30'),
(79, 33, 41, 0, '2014-12-30'),
(80, 36, 41, 0, '2014-12-30'),
(81, 27, 42, 5, '2014-12-30'),
(82, 33, 42, 0, '2014-12-30'),
(83, 36, 42, 0, '2014-12-30'),
(84, 27, 43, 5, '2014-12-30'),
(85, 33, 43, 0, '2014-12-30'),
(86, 36, 43, 0, '2014-12-30'),
(87, 27, 44, 5, '2014-12-30'),
(88, 33, 44, 0, '2014-12-30'),
(89, 36, 44, 0, '2014-12-30'),
(90, 27, 45, 5, '2014-12-30'),
(91, 33, 45, 0, '2014-12-30'),
(92, 36, 45, 0, '2014-12-30'),
(93, 27, 46, 5, '2014-12-30'),
(94, 33, 46, 0, '2014-12-30'),
(95, 36, 46, 0, '2014-12-30'),
(96, 27, 47, 5, '2014-12-30'),
(97, 33, 47, 0, '2014-12-30'),
(98, 36, 47, 0, '2014-12-30'),
(99, 27, 48, 5, '2014-12-30'),
(100, 33, 48, 0, '2014-12-30'),
(101, 36, 48, 0, '2014-12-30'),
(102, 27, 49, 5, '2014-12-30'),
(103, 33, 49, 0, '2014-12-30'),
(104, 36, 49, 0, '2014-12-30'),
(105, 27, 50, 6, '2014-12-30'),
(106, 33, 50, 0, '2014-12-30'),
(107, 36, 50, 0, '2014-12-30'),
(108, 27, 51, 6, '2014-12-30'),
(109, 33, 51, 0, '2014-12-30'),
(110, 36, 51, 0, '2014-12-30'),
(111, 27, 52, 6, '2014-12-30'),
(112, 33, 52, 0, '2014-12-30'),
(113, 36, 52, 0, '2014-12-30'),
(114, 27, 53, 6, '2014-12-30'),
(115, 33, 53, 0, '2014-12-30'),
(116, 36, 53, 0, '2014-12-30'),
(117, 27, 54, 6, '2014-12-30'),
(118, 33, 54, 0, '2014-12-30'),
(119, 36, 54, 0, '2014-12-30'),
(120, 27, 55, 6, '2014-12-30'),
(121, 33, 55, 0, '2014-12-30'),
(122, 36, 55, 0, '2014-12-30'),
(123, 27, 56, 6, '2014-12-30'),
(124, 33, 56, 0, '2014-12-30'),
(125, 36, 56, 0, '2014-12-30'),
(126, 27, 57, 7, '2014-12-30'),
(127, 33, 57, 0, '2014-12-30'),
(128, 36, 57, 0, '2014-12-30'),
(129, 27, 58, 1, '2014-12-30'),
(130, 33, 58, 0, '2014-12-30'),
(131, 36, 58, 0, '2014-12-30'),
(132, 27, 59, 1, '2014-12-30'),
(133, 33, 59, 0, '2014-12-30'),
(134, 36, 59, 0, '2014-12-30'),
(135, 27, 60, 1, '2014-12-30'),
(136, 33, 60, 0, '2014-12-30'),
(137, 36, 60, 0, '2014-12-30'),
(138, 27, 61, 1, '2014-12-30'),
(139, 33, 61, 0, '2014-12-30'),
(140, 36, 61, 0, '2014-12-30'),
(141, 40, 60, 58, '2014-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_option`
--

DROP TABLE IF EXISTS `product_attribute_value_option`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`),
  KEY `product_id` (`product_id`),
  KEY `value_id` (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=144 ;

--
-- Dumping data for table `product_attribute_value_option`
--

INSERT INTO `product_attribute_value_option` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 16, 3, 8, '0000-00-00'),
(2, 16, 4, 7, '0000-00-00'),
(3, 16, 5, 8, '0000-00-00'),
(4, 16, 6, 8, '0000-00-00'),
(5, 16, 7, 8, '0000-00-00'),
(6, 16, 8, 8, '0000-00-00'),
(7, 25, 11, 11, '2014-12-30'),
(8, 26, 11, 13, '2014-12-27'),
(9, 25, 12, 12, '2014-12-30'),
(10, 26, 12, 13, '2014-12-27'),
(11, 25, 13, 12, '2014-12-30'),
(12, 26, 13, 13, '2014-12-27'),
(13, 25, 14, 12, '2014-12-30'),
(14, 26, 14, 13, '2014-12-27'),
(15, 25, 15, 11, '2014-12-30'),
(16, 26, 15, 13, '2014-12-27'),
(17, 16, 16, 7, '2014-12-08'),
(18, 16, 17, 8, '2014-12-08'),
(19, 25, 18, 12, '2014-12-30'),
(20, 26, 18, 13, '2014-12-27'),
(21, 16, 19, 8, '2014-12-08'),
(22, 25, 20, 12, '2014-12-30'),
(23, 26, 20, 13, '2014-12-27'),
(24, 25, 21, 11, '2014-12-27'),
(25, 26, 21, 13, '2014-12-27'),
(26, 32, 12, 19, '2014-12-27'),
(27, 32, 12, 19, '2014-12-27'),
(28, 32, 12, 19, '2014-12-27'),
(29, 25, 21, 11, '2014-12-28'),
(30, 26, 21, 13, '2014-12-28'),
(31, 32, 21, 18, '2014-12-28'),
(32, 25, 21, 12, '2014-12-28'),
(33, 26, 21, 13, '2014-12-28'),
(34, 32, 21, 18, '2014-12-28'),
(36, 25, 24, 13, '2014-12-28'),
(37, 25, 25, 13, '2014-12-28'),
(38, 25, 26, 13, '2014-12-28'),
(39, 25, 27, 13, '2014-12-28'),
(40, 25, 28, 11, '2014-12-30'),
(41, 25, 29, 12, '2014-12-30'),
(42, 25, 30, 12, '2014-12-30'),
(43, 25, 31, 12, '2014-12-30'),
(47, 25, 32, 13, '2014-12-29'),
(49, 25, 33, 13, '2014-12-29'),
(51, 25, 34, 13, '2014-12-29'),
(53, 38, 11, 17, '2014-12-30'),
(54, 38, 31, 17, '2014-12-30'),
(55, 38, 30, 17, '2014-12-30'),
(56, 38, 29, 17, '2014-12-30'),
(57, 38, 28, 17, '2014-12-30'),
(58, 38, 20, 17, '2014-12-30'),
(59, 38, 18, 17, '2014-12-30'),
(60, 38, 15, 17, '2014-12-30'),
(61, 38, 14, 17, '2014-12-30'),
(62, 38, 13, 17, '2014-12-30'),
(63, 38, 12, 17, '2014-12-30'),
(64, 25, 35, 13, '2014-12-30'),
(66, 25, 36, 13, '2014-12-30'),
(67, 25, 37, 11, '2014-12-30'),
(68, 38, 37, 16, '2014-12-30'),
(69, 39, 37, 18, '2014-12-30'),
(70, 25, 38, 12, '2014-12-30'),
(71, 38, 38, 16, '2014-12-30'),
(72, 39, 38, 18, '2014-12-30'),
(73, 25, 39, 11, '2014-12-30'),
(74, 38, 39, 16, '2014-12-30'),
(75, 39, 39, 18, '2014-12-30'),
(76, 25, 40, 11, '2014-12-30'),
(77, 38, 40, 16, '2014-12-30'),
(78, 39, 40, 18, '2014-12-30'),
(79, 25, 41, 11, '2014-12-30'),
(80, 38, 41, 16, '2014-12-30'),
(81, 39, 41, 18, '2014-12-30'),
(82, 25, 42, 11, '2014-12-30'),
(83, 38, 42, 16, '2014-12-30'),
(84, 39, 42, 18, '2014-12-30'),
(85, 25, 43, 11, '2014-12-30'),
(86, 38, 43, 16, '2014-12-30'),
(87, 39, 43, 18, '2014-12-30'),
(88, 25, 44, 11, '2014-12-30'),
(89, 38, 44, 16, '2014-12-30'),
(90, 39, 44, 18, '2014-12-30'),
(91, 25, 45, 11, '2014-12-30'),
(92, 38, 45, 16, '2014-12-30'),
(93, 39, 45, 18, '2014-12-30'),
(94, 25, 46, 11, '2014-12-30'),
(95, 38, 46, 16, '2014-12-30'),
(96, 39, 46, 18, '2014-12-30'),
(97, 25, 47, 11, '2014-12-30'),
(98, 38, 47, 16, '2014-12-30'),
(99, 39, 47, 18, '2014-12-30'),
(100, 25, 48, 11, '2014-12-30'),
(101, 38, 48, 16, '2014-12-30'),
(102, 39, 48, 18, '2014-12-30'),
(103, 25, 49, 11, '2014-12-30'),
(104, 38, 49, 16, '2014-12-30'),
(105, 39, 49, 18, '2014-12-30'),
(106, 25, 50, 11, '2014-12-30'),
(107, 38, 50, 16, '2014-12-30'),
(108, 39, 50, 18, '2014-12-30'),
(109, 25, 51, 11, '2014-12-30'),
(110, 38, 51, 16, '2014-12-30'),
(111, 39, 51, 18, '2014-12-30'),
(112, 25, 52, 11, '2014-12-30'),
(113, 38, 52, 16, '2014-12-30'),
(114, 39, 52, 18, '2014-12-30'),
(115, 25, 53, 11, '2014-12-30'),
(116, 38, 53, 16, '2014-12-30'),
(117, 39, 53, 18, '2014-12-30'),
(118, 25, 54, 11, '2014-12-30'),
(119, 38, 54, 16, '2014-12-30'),
(120, 39, 54, 18, '2014-12-30'),
(121, 25, 55, 11, '2014-12-30'),
(122, 38, 55, 16, '2014-12-30'),
(123, 39, 55, 18, '2014-12-30'),
(124, 25, 56, 11, '2014-12-30'),
(125, 38, 56, 16, '2014-12-30'),
(126, 39, 56, 18, '2014-12-30'),
(127, 25, 57, 11, '2014-12-30'),
(128, 38, 57, 16, '2014-12-30'),
(129, 39, 57, 18, '2014-12-30'),
(130, 25, 58, 11, '2014-12-30'),
(131, 38, 58, 16, '2014-12-30'),
(132, 39, 58, 18, '2014-12-30'),
(133, 25, 59, 12, '2014-12-30'),
(134, 38, 59, 16, '2014-12-30'),
(135, 39, 59, 18, '2014-12-30'),
(136, 25, 60, 12, '2014-12-30'),
(137, 38, 60, 16, '2014-12-30'),
(138, 39, 60, 18, '2014-12-30'),
(139, 25, 61, 12, '2014-12-30'),
(140, 38, 61, 16, '2014-12-30'),
(141, 39, 61, 18, '2014-12-30'),
(142, 37, 59, 15, '2014-12-30'),
(143, 37, 60, 15, '2014-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_text`
--

DROP TABLE IF EXISTS `product_attribute_value_text`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE IF NOT EXISTS `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id`, `product_id`, `category_id`, `sort_order`) VALUES
(1, 3, 2, 0),
(2, 3, 3, 0),
(3, 4, 2, 0),
(4, 5, 2, 0),
(5, 5, 3, 0),
(6, 6, 2, 0),
(7, 6, 3, 0),
(8, 7, 2, 0),
(9, 7, 3, 0),
(10, 8, 3, 0),
(25, 17, 3, 0),
(30, 16, 3, 0),
(32, 19, 3, 0),
(49, 21, 4, 0),
(50, 23, 5, 0),
(51, 24, 4, 0),
(52, 25, 4, 0),
(53, 26, 4, 0),
(54, 27, 4, 0),
(57, 32, 4, 0),
(58, 33, 4, 0),
(59, 34, 4, 0),
(60, 11, 4, 0),
(61, 31, 4, 0),
(62, 30, 4, 0),
(63, 29, 4, 0),
(64, 28, 4, 0),
(65, 20, 4, 0),
(66, 18, 4, 0),
(67, 15, 4, 0),
(68, 14, 4, 0),
(70, 13, 4, 0),
(71, 12, 4, 0),
(72, 35, 4, 0),
(73, 36, 4, 0),
(74, 37, 4, 0),
(75, 38, 4, 0),
(76, 41, 4, 0),
(77, 42, 4, 0),
(78, 43, 4, 0),
(79, 44, 4, 0),
(80, 45, 4, 0),
(81, 46, 4, 0),
(82, 47, 4, 0),
(83, 48, 4, 0),
(84, 49, 4, 0),
(85, 56, 4, 0),
(86, 57, 4, 0),
(87, 58, 4, 0),
(88, 59, 4, 0),
(89, 60, 4, 0),
(90, 61, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder_product`
--

DROP TABLE IF EXISTS `purchaseorder_product`;
CREATE TABLE IF NOT EXISTS `purchaseorder_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unit_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_id` (`purchase_order_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `purchaseorder_product`
--

INSERT INTO `purchaseorder_product` (`id`, `purchase_order_id`, `product_id`, `unit_price`, `quantity`, `total_price`) VALUES
(5, 6, 3, 20, 20, 400),
(6, 6, 4, 21.25, 20, 425),
(7, 7, 4, 20, 0, 0),
(8, 8, 17, 101, 10, 1010),
(9, 8, 16, 10, 1, 10),
(10, 9, 16, 200, 10, 2000),
(11, 9, 18, 100, 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `purchase_order_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `purchase_order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purchase_order_recieve_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `purchase_order_assigned_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`purchase_order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`purchase_order_id`, `employee_id`, `purchase_order_date`, `purchase_order_recieve_date`, `purchase_order_assigned_date`) VALUES
(6, 0, '2014-11-28 18:15:00', '2014-11-28 18:15:00', '2014-11-28 18:15:00'),
(7, 0, '2014-11-29 18:15:00', '2014-11-29 18:15:00', '2014-11-29 18:15:00'),
(8, 0, '2014-12-08 18:15:00', '2014-12-08 18:15:00', '2014-12-08 18:15:00'),
(9, 0, '2014-12-08 18:15:00', '2014-12-08 18:15:00', '2014-12-08 18:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `rabbit_litters`
--

DROP TABLE IF EXISTS `rabbit_litters`;
CREATE TABLE IF NOT EXISTS `rabbit_litters` (
  `litter_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `parent_buck_id` int(11) DEFAULT NULL,
  `family_id` int(11) NOT NULL,
  `litters_dob` date NOT NULL,
  `litters_weaning_date` date NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`litter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `rabbit_litters`
--

INSERT INTO `rabbit_litters` (`litter_id`, `parent_id`, `parent_buck_id`, `family_id`, `litters_dob`, `litters_weaning_date`, `updated_date`) VALUES
(60, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30'),
(61, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30'),
(62, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30'),
(63, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30'),
(64, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30'),
(65, 60, 58, 1, '2014-12-30', '0000-00-00', '2014-12-30');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aa_litter`
--
ALTER TABLE `aa_litter`
  ADD CONSTRAINT `aa_litter_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `aa_family` (`f_id`);

--
-- Constraints for table `aa_rabbits`
--
ALTER TABLE `aa_rabbits`
  ADD CONSTRAINT `aa_rabbits_ibfk_1` FOREIGN KEY (`l_id`) REFERENCES `aa_litter` (`l_id`),
  ADD CONSTRAINT `aa_rabbits_ibfk_2` FOREIGN KEY (`f_id`) REFERENCES `aa_family` (`f_id`);

--
-- Constraints for table `attribute_attributeset`
--
ALTER TABLE `attribute_attributeset`
  ADD CONSTRAINT `attribute_attributeset_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `attribute_attributeset_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD CONSTRAINT `attribute_values_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products_inventory`
--
ALTER TABLE `products_inventory`
  ADD CONSTRAINT `products_inventory_ibfk_1` FOREIGN KEY (`product_type_id`) REFERENCES `products_type` (`id`),
  ADD CONSTRAINT `products_inventory_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`);

--
-- Constraints for table `product_attribute_value_number`
--
ALTER TABLE `product_attribute_value_number`
  ADD CONSTRAINT `product_attribute_value_number_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_number_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_attribute_value_option`
--
ALTER TABLE `product_attribute_value_option`
  ADD CONSTRAINT `product_attribute_value_option_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_option_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_option_ibfk_3` FOREIGN KEY (`value`) REFERENCES `attribute_values` (`id`);

--
-- Constraints for table `product_attribute_value_text`
--
ALTER TABLE `product_attribute_value_text`
  ADD CONSTRAINT `product_attribute_value_text_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_attribute_value_text_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_category`
--
ALTER TABLE `product_category`
  ADD CONSTRAINT `product_category_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `product_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchaseorder_product`
--
ALTER TABLE `purchaseorder_product`
  ADD CONSTRAINT `purchaseorder_product_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`purchase_order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `purchaseorder_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`);
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
