-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2015 at 09:54 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `aa_death`
--

DROP TABLE IF EXISTS `aa_death`;
CREATE TABLE IF NOT EXISTS `aa_death` (
`d_id` bigint(100) NOT NULL,
  `rid` bigint(20) DEFAULT NULL,
  `lid` bigint(100) DEFAULT NULL,
  `death_reason` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_death`
--

INSERT INTO `aa_death` (`d_id`, `rid`, `lid`, `death_reason`) VALUES
(13, 183, NULL, 'dsf'),
(15, NULL, 56, 'asdf'),
(16, 127, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `aa_family`
--

DROP TABLE IF EXISTS `aa_family`;
CREATE TABLE IF NOT EXISTS `aa_family` (
`f_id` bigint(20) NOT NULL,
  `created_DT` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_family`
--

INSERT INTO `aa_family` (`f_id`, `created_DT`) VALUES
(1, '2014-12-30'),
(2, '2015-01-09');

-- --------------------------------------------------------

--
-- Table structure for table `aa_family_to_be`
--

DROP TABLE IF EXISTS `aa_family_to_be`;
CREATE TABLE IF NOT EXISTS `aa_family_to_be` (
  `buck_r_id` bigint(20) NOT NULL,
  `doe_r_id` bigint(20) NOT NULL,
`ID` bigint(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_family_to_be`
--

INSERT INTO `aa_family_to_be` (`buck_r_id`, `doe_r_id`, `ID`) VALUES
(116, 116, 1),
(126, 58, 2),
(126, 59, 3),
(126, 60, 4),
(126, 61, 5),
(127, 58, 6),
(127, 59, 7),
(127, 60, 8),
(127, 61, 9),
(127, 126, 10),
(127, 127, 11),
(131, 58, 12),
(131, 59, 13),
(131, 60, 14),
(131, 61, 15),
(131, 127, 16),
(133, 58, 17),
(133, 59, 18),
(133, 60, 19),
(133, 61, 20),
(133, 127, 21),
(154, 58, 22),
(154, 59, 23),
(154, 60, 24),
(154, 61, 25),
(154, 127, 26),
(158, 58, 27),
(158, 59, 28),
(158, 60, 29),
(158, 61, 30),
(158, 127, 31),
(160, 58, 32),
(160, 59, 33),
(160, 60, 34),
(160, 61, 35),
(160, 127, 36),
(162, 58, 37),
(162, 59, 38),
(162, 60, 39),
(162, 61, 40),
(162, 127, 41),
(167, 58, 42),
(167, 59, 43),
(167, 60, 44),
(167, 61, 45),
(167, 127, 46),
(169, 58, 47),
(169, 59, 48),
(169, 60, 49),
(169, 61, 50),
(169, 127, 51),
(171, 58, 52),
(171, 59, 53),
(171, 60, 54),
(171, 61, 55),
(171, 127, 56),
(172, 58, 57),
(172, 59, 58),
(172, 60, 59),
(172, 61, 60),
(172, 127, 61),
(202, 202, 62),
(203, 202, 63),
(203, 203, 64),
(204, 202, 65),
(204, 203, 66),
(204, 204, 67),
(205, 205, 68),
(208, 205, 69),
(208, 208, 70);

-- --------------------------------------------------------

--
-- Table structure for table `aa_litter`
--

DROP TABLE IF EXISTS `aa_litter`;
CREATE TABLE IF NOT EXISTS `aa_litter` (
`l_id` bigint(20) NOT NULL,
  `f_id` bigint(20) NOT NULL,
  `DOB` date NOT NULL,
  `does_no` bigint(20) NOT NULL,
  `bucks_no` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_litter`
--

INSERT INTO `aa_litter` (`l_id`, `f_id`, `DOB`, `does_no`, `bucks_no`) VALUES
(27, 1, '2015-01-09', 0, 0),
(28, 1, '2015-01-09', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `aa_rabbits`
--

DROP TABLE IF EXISTS `aa_rabbits`;
CREATE TABLE IF NOT EXISTS `aa_rabbits` (
`r_id` bigint(20) NOT NULL,
  `type` enum('B','D') NOT NULL,
  `l_id` bigint(20) DEFAULT NULL,
  `f_id` bigint(20) DEFAULT NULL,
  `does_id` bigint(20) DEFAULT NULL,
  `buck_id` bigint(20) DEFAULT NULL,
  `last_given_birth` date DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `rabbit_slug` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aa_rabbits`
--

INSERT INTO `aa_rabbits` (`r_id`, `type`, `l_id`, `f_id`, `does_id`, `buck_id`, `last_given_birth`, `status`, `rabbit_slug`) VALUES
(202, 'B', NULL, 1, 0, 0, NULL, '1', 'RB01'),
(203, 'D', NULL, 1, 0, 0, NULL, '0', 'RB02'),
(204, 'D', NULL, 1, 0, 0, NULL, '1', 'RB03'),
(205, 'D', NULL, 1, 0, 0, NULL, '1', 'RB04'),
(208, 'D', NULL, 2, 0, 0, NULL, '1', 'RB05');

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
CREATE TABLE IF NOT EXISTS `attributes` (
`attribute_id` int(11) NOT NULL,
  `attribute_code` varchar(255) NOT NULL,
  `attribute_default_value` text NOT NULL,
  `attribute_type` enum('number','text','date','select','multiselect') NOT NULL,
  `attribute_requires_editor` enum('0','1') NOT NULL,
  `attribute_admin_label` varchar(255) NOT NULL,
  `attribute_frontend_label` varchar(255) NOT NULL,
  `is_unique` enum('0','1') NOT NULL,
  `is_required` enum('0','1') NOT NULL,
  `is_used_for_variation` enum('0','1') NOT NULL,
  `is_hidden` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`attribute_id`, `attribute_code`, `attribute_default_value`, `attribute_type`, `attribute_requires_editor`, `attribute_admin_label`, `attribute_frontend_label`, `is_unique`, `is_required`, `is_used_for_variation`, `is_hidden`) VALUES
(16, 'weight', '0', 'number', '0', 'Weight', 'Weight', '0', '1', '', '0'),
(18, 'test', 'test', 'select', '0', 'test', 'test', '0', '0', '0', '0'),
(25, 'rabbit_gender', '', 'select', '0', 'Gender', 'Gender', '0', '0', '', '0'),
(27, 'rabbit_family_id', '', 'number', '0', 'Family ID', 'Family ID', '0', '0', '0', '0'),
(28, 'rabbit_dob', '', 'date', '0', 'DOB', 'DOB', '0', '0', '0', '0'),
(29, 'rabbit_latest_mate_date', '', 'date', '0', 'Mated Date', 'Mated Date', '0', '0', '0', '0'),
(30, 'rabbit_latest_pregnant_date', '', 'date', '0', 'Pregnant Date', 'Pregnant Date', '0', '0', '0', '0'),
(31, 'rabbit_latest_birth_date', '0000-00-00', 'date', '0', 'Latest Birth Date', 'Latest Birth Date', '0', '0', '', '0'),
(33, 'litters_born', '', 'number', '0', 'Litters Born', 'Litters Born', '0', '0', '0', '0'),
(34, 'rabbit_latest_weaning_date', '', 'date', '0', 'Latest Weaning Date', 'Latest Weaning Date', '0', '0', '0', '0'),
(35, 'rabbit_latest_culling_date', '', 'date', '0', 'Latest Culling Date', 'Latest Culling Date', '0', '0', '0', '0'),
(36, 'parent_id', '', 'number', '0', 'Parent Rabbit', 'Parent Rabbit', '0', '1', '', '1'),
(37, 'is_pregnant', '', 'select', '0', 'Is Pregnant', 'Is Pregnant', '0', '0', '0', '0'),
(38, 'is_matured', '', 'select', '0', 'Matured', 'Matured', '0', '1', '0', '0'),
(39, 'rabbit_group', '', 'select', '0', 'Rabbit Group', 'Rabbit Group', '0', '1', '0', '0'),
(40, 'recently_mated_buck', '0', 'number', '0', 'Recently Mated Buck', 'Recently Mated Buck', '0', '0', '', '1'),
(41, 'parent_doe_id', '', 'number', '0', 'Parent Doe (TO BE UPDATED BY SYSTEM)', 'Parent Doe', '0', '0', '', '1'),
(42, 'parent_buck_id', '', 'number', '0', 'Parent Buck (TO BE UPDATED BY SYSTEM)', 'Parent Buck', '0', '0', '', '1'),
(43, 'litter_id', '', 'number', '0', 'Litter Group', 'Litter Group', '0', '0', '', '1'),
(44, 'is_litter', '', 'select', '0', 'Is Litter', 'Is Litter', '0', '0', '0', '0'),
(45, '', '', 'number', '0', '', '', '0', '0', '0', '0'),
(46, 'rabbit_feeding_group', '', 'select', '0', 'Feeding Group', 'Feeding Group', '0', '1', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_attributeset`
--

DROP TABLE IF EXISTS `attribute_attributeset`;
CREATE TABLE IF NOT EXISTS `attribute_attributeset` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attribute_attributeset`
--

INSERT INTO `attribute_attributeset` (`id`, `attribute_id`, `attribute_set_id`, `sort_order`) VALUES
(9, 25, 4, 0),
(11, 27, 4, 2),
(12, 28, 4, 3),
(13, 29, 4, 4),
(14, 30, 4, 5),
(15, 16, 5, 0),
(16, 31, 4, 6),
(19, 34, 4, 9),
(20, 35, 4, 10),
(21, 27, 6, 0),
(22, 36, 6, 1),
(24, 38, 4, 11),
(25, 39, 4, 11),
(26, 40, 4, 12),
(27, 41, 4, 13),
(28, 42, 4, 14),
(29, 43, 4, 15),
(30, 36, 4, 8),
(31, 44, 4, 15),
(32, 46, 4, 16),
(33, 16, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_sets`
--

DROP TABLE IF EXISTS `attribute_sets`;
CREATE TABLE IF NOT EXISTS `attribute_sets` (
`attribute_set_id` int(11) NOT NULL,
  `attribute_set_code` varchar(255) NOT NULL,
  `attribute_set_name` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attribute_sets`
--

INSERT INTO `attribute_sets` (`attribute_set_id`, `attribute_set_code`, `attribute_set_name`, `sort_order`) VALUES
(4, 'rabbit', 'Rabbit', 0),
(5, 'feed', 'Feed', 1),
(6, 'litters', 'Litters', 2);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

DROP TABLE IF EXISTS `attribute_values`;
CREATE TABLE IF NOT EXISTS `attribute_values` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`id`, `attribute_id`, `value`, `sort_order`) VALUES
(11, 25, 'Male', 0),
(12, 25, 'Female', 1),
(13, 25, 'Litter', 2),
(14, 37, 'No', 0),
(15, 37, 'Yes', 1),
(16, 38, 'No', 0),
(17, 38, 'Yes', 1),
(18, 39, 'Parents', 0),
(19, 39, 'Parents to be', 1),
(20, 39, 'Products', 2),
(21, 39, 'Products to be ', 3),
(22, 44, 'No', 0),
(23, 44, 'yes', 1),
(24, 46, 'Adult Male', 0),
(25, 46, 'Adult Female', 1),
(26, 46, 'Pregnant/Lactating', 2),
(27, 46, 'Litters', 3);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
`category_id` int(11) NOT NULL,
  `category_code` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_display_name` varchar(255) NOT NULL,
  `category_description` text NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_root` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_code`, `category_name`, `category_display_name`, `category_description`, `parent_id`, `is_root`, `sort_order`) VALUES
(2, 'food', 'Food', 'Food', 'Food for rabbits', 0, '1', 0),
(3, 'feed', 'Feed', 'Feed', 'Feed for rabbits', 2, '0', 0),
(4, 'rabbits', 'Rabbits', 'Rabbits', '', 0, '0', 0),
(5, 'litters', 'Litters', 'Litters', '', 0, '0', 3);

-- --------------------------------------------------------

--
-- Table structure for table `products_inventory`
--

DROP TABLE IF EXISTS `products_inventory`;
CREATE TABLE IF NOT EXISTS `products_inventory` (
`product_id` int(11) NOT NULL,
  `product_type_id` int(11) NOT NULL,
  `attribute_set_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sku` varchar(255) NOT NULL,
  `parent_doe_id` int(11) DEFAULT NULL,
  `parent_buck_id` int(11) DEFAULT NULL,
  `daily_use_status` enum('0','1') NOT NULL DEFAULT '0',
  `daily_use_quantity` double DEFAULT NULL,
  `product_quantity` double NOT NULL,
  `in_stock` enum('0','1') NOT NULL,
  `unit_price` double NOT NULL,
  `status` enum('0','1') NOT NULL,
  `is_variation` enum('0','1') NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product_type` enum('in','out') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_inventory`
--

INSERT INTO `products_inventory` (`product_id`, `product_type_id`, `attribute_set_id`, `product_name`, `product_sku`, `parent_doe_id`, `parent_buck_id`, `daily_use_status`, `daily_use_quantity`, `product_quantity`, `in_stock`, `unit_price`, `status`, `is_variation`, `sort_order`, `created_date`, `updated_date`, `product_type`) VALUES
(202, 1, 4, 'RB01', 'RB01', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(203, 1, 4, 'RB02', 'RB02', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(204, 1, 4, 'RB03', 'RB03', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(205, 1, 4, 'RB04', 'RB04', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(208, 1, 4, 'RB05', 'RB05', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(213, 1, 4, 'RB_209', 'rb_209', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(214, 1, 4, 'RB_214', 'rb_214', NULL, NULL, '0', 0, 1, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-08 18:15:00', 'out'),
(215, 1, 5, 'Concentrated Feed', 'concentrated_feed', NULL, NULL, '1', 0, 49639, '1', 100, '1', '0', 0, '2015-01-08 18:15:00', '2015-01-09 08:49:55', 'in');

-- --------------------------------------------------------

--
-- Table structure for table `products_type`
--

DROP TABLE IF EXISTS `products_type`;
CREATE TABLE IF NOT EXISTS `products_type` (
`id` int(11) NOT NULL,
  `product_type_code` varchar(255) NOT NULL,
  `product_type_name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_type`
--

INSERT INTO `products_type` (`id`, `product_type_code`, `product_type_name`) VALUES
(1, 'simple', 'Simple');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_date`
--

DROP TABLE IF EXISTS `product_attribute_value_date`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_date` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` date NOT NULL,
  `updated_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_attribute_value_date`
--

INSERT INTO `product_attribute_value_date` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 28, 202, '2015-01-09', '2015-01-09'),
(2, 29, 202, '2015-01-09', '2015-01-09'),
(3, 30, 202, '0000-00-00', '2015-01-09'),
(4, 31, 202, '0000-00-00', '2015-01-09'),
(5, 34, 202, '0000-00-00', '2015-01-09'),
(6, 35, 202, '0000-00-00', '2015-01-09'),
(7, 28, 203, '2015-01-09', '2015-01-09'),
(12, 35, 203, '0000-00-00', '2015-01-09'),
(13, 28, 204, '2015-01-09', '2015-01-09'),
(14, 29, 204, '0000-00-00', '2015-01-09'),
(15, 30, 204, '0000-00-00', '2015-01-09'),
(16, 31, 204, '0000-00-00', '2015-01-09'),
(17, 34, 204, '0000-00-00', '2015-01-09'),
(18, 35, 204, '0000-00-00', '2015-01-09'),
(19, 28, 205, '2015-01-09', '2015-01-09'),
(20, 29, 205, '0000-00-00', '2015-01-09'),
(21, 30, 205, '0000-00-00', '2015-01-09'),
(22, 31, 205, '0000-00-00', '2015-01-09'),
(23, 34, 205, '0000-00-00', '2015-01-09'),
(24, 35, 205, '0000-00-00', '2015-01-09'),
(25, 28, 206, '2015-01-09', '2015-01-09'),
(26, 29, 206, '0000-00-00', '2015-01-09'),
(27, 30, 206, '0000-00-00', '2015-01-09'),
(28, 31, 206, '0000-00-00', '2015-01-09'),
(29, 34, 206, '0000-00-00', '2015-01-09'),
(30, 35, 206, '0000-00-00', '2015-01-09'),
(31, 28, 207, '2015-01-09', '2015-01-09'),
(32, 29, 207, '0000-00-00', '2015-01-09'),
(33, 30, 207, '0000-00-00', '2015-01-09'),
(34, 31, 207, '0000-00-00', '2015-01-09'),
(35, 34, 207, '0000-00-00', '2015-01-09'),
(36, 35, 207, '0000-00-00', '2015-01-09'),
(37, 28, 208, '2015-01-09', '2015-01-09'),
(38, 29, 208, '0000-00-00', '2015-01-09'),
(39, 30, 208, '0000-00-00', '2015-01-09'),
(40, 31, 208, '0000-00-00', '2015-01-09'),
(41, 34, 208, '0000-00-00', '2015-01-09'),
(42, 35, 208, '0000-00-00', '2015-01-09'),
(43, 28, 209, '2015-01-09', '2015-01-09'),
(44, 29, 209, '0000-00-00', '2015-01-09'),
(45, 30, 209, '0000-00-00', '2015-01-09'),
(46, 31, 209, '0000-00-00', '2015-01-09'),
(47, 34, 209, '2015-01-09', '2015-01-09'),
(48, 35, 209, '0000-00-00', '2015-01-09'),
(49, 28, 210, '2015-01-09', '2015-01-09'),
(50, 29, 210, '0000-00-00', '2015-01-09'),
(51, 30, 210, '0000-00-00', '2015-01-09'),
(52, 31, 210, '0000-00-00', '2015-01-09'),
(53, 34, 210, '2015-01-09', '2015-01-09'),
(54, 35, 210, '0000-00-00', '2015-01-09'),
(55, 28, 211, '2015-01-09', '2015-01-09'),
(56, 29, 211, '0000-00-00', '2015-01-09'),
(57, 30, 211, '0000-00-00', '2015-01-09'),
(58, 31, 211, '0000-00-00', '2015-01-09'),
(59, 34, 211, '2015-01-09', '2015-01-09'),
(60, 35, 211, '0000-00-00', '2015-01-09'),
(61, 28, 212, '2015-01-09', '2015-01-09'),
(62, 29, 212, '0000-00-00', '2015-01-09'),
(63, 30, 212, '0000-00-00', '2015-01-09'),
(64, 31, 212, '0000-00-00', '2015-01-09'),
(65, 34, 212, '2015-01-09', '2015-01-09'),
(66, 35, 212, '0000-00-00', '2015-01-09'),
(67, 29, 203, '2014-12-25', '2015-01-09'),
(68, 30, 203, '2014-12-13', '2015-01-09'),
(69, 31, 203, '2014-12-13', '2015-01-09'),
(70, 28, 213, '2015-01-09', '2015-01-09'),
(71, 29, 213, '0000-00-00', '2015-01-09'),
(72, 30, 213, '0000-00-00', '2015-01-09'),
(73, 31, 213, '0000-00-00', '2015-01-09'),
(74, 34, 213, '2015-01-09', '2015-01-09'),
(75, 35, 213, '0000-00-00', '2015-01-09'),
(76, 28, 214, '2015-01-09', '2015-01-09'),
(77, 29, 214, '0000-00-00', '2015-01-09'),
(78, 30, 214, '0000-00-00', '2015-01-09'),
(79, 31, 214, '0000-00-00', '2015-01-09'),
(80, 34, 214, '2015-01-09', '2015-01-09'),
(81, 35, 214, '0000-00-00', '2015-01-09');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_number`
--

DROP TABLE IF EXISTS `product_attribute_value_number`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_number` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` float NOT NULL,
  `updated_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_attribute_value_number`
--

INSERT INTO `product_attribute_value_number` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 27, 202, 1, '2015-01-09'),
(2, 40, 202, 0, '2015-01-09'),
(3, 41, 202, 0, '2015-01-09'),
(4, 42, 202, 0, '2015-01-09'),
(5, 43, 202, 0, '2015-01-09'),
(6, 36, 202, 0, '2015-01-09'),
(7, 16, 202, 3, '2015-01-09'),
(8, 27, 203, 1, '2015-01-09'),
(9, 40, 203, 202, '2015-01-09'),
(10, 41, 203, 0, '2015-01-09'),
(11, 42, 203, 0, '2015-01-09'),
(12, 43, 203, 0, '2015-01-09'),
(13, 36, 203, 0, '2015-01-09'),
(14, 16, 203, 3, '2015-01-09'),
(15, 27, 204, 1, '2015-01-09'),
(16, 40, 204, 0, '2015-01-09'),
(17, 41, 204, 0, '2015-01-09'),
(18, 42, 204, 0, '2015-01-09'),
(19, 43, 204, 0, '2015-01-09'),
(20, 36, 204, 0, '2015-01-09'),
(21, 16, 204, 2.5, '2015-01-09'),
(22, 27, 205, 1, '2015-01-09'),
(23, 40, 205, 0, '2015-01-09'),
(24, 41, 205, 0, '2015-01-09'),
(25, 42, 205, 0, '2015-01-09'),
(26, 43, 205, 0, '2015-01-09'),
(27, 36, 205, 0, '2015-01-09'),
(28, 16, 205, 2.5, '2015-01-09'),
(29, 27, 206, 2, '2015-01-09'),
(30, 40, 206, 0, '2015-01-09'),
(31, 41, 206, 0, '2015-01-09'),
(32, 42, 206, 0, '2015-01-09'),
(33, 43, 206, 0, '2015-01-09'),
(34, 36, 206, 0, '2015-01-09'),
(35, 16, 206, 2.2, '2015-01-09'),
(36, 27, 207, 2, '2015-01-09'),
(37, 40, 207, 0, '2015-01-09'),
(38, 41, 207, 0, '2015-01-09'),
(39, 42, 207, 0, '2015-01-09'),
(40, 43, 207, 0, '2015-01-09'),
(41, 36, 207, 0, '2015-01-09'),
(42, 16, 207, 2.2, '2015-01-09'),
(43, 27, 208, 2, '2015-01-09'),
(44, 40, 208, 0, '2015-01-09'),
(45, 41, 208, 0, '2015-01-09'),
(46, 42, 208, 0, '2015-01-09'),
(47, 43, 208, 0, '2015-01-09'),
(48, 36, 208, 0, '2015-01-09'),
(49, 16, 208, 2.2, '2015-01-09'),
(50, 27, 209, 1, '2015-01-09'),
(51, 16, 209, 2.5, '2015-01-09'),
(52, 43, 209, 27, '2015-01-09'),
(53, 41, 209, 203, '2015-01-09'),
(54, 42, 209, 202, '2015-01-09'),
(55, 27, 210, 1, '2015-01-09'),
(56, 16, 210, 0.6, '2015-01-09'),
(57, 43, 210, 27, '2015-01-09'),
(58, 41, 210, 203, '2015-01-09'),
(59, 42, 210, 202, '2015-01-09'),
(60, 40, 209, 0, '2015-01-09'),
(61, 36, 209, 0, '2015-01-09'),
(62, 27, 211, 1, '2015-01-09'),
(63, 16, 211, 0.7, '2015-01-09'),
(64, 43, 211, 27, '2015-01-09'),
(65, 41, 211, 203, '2015-01-09'),
(66, 42, 211, 202, '2015-01-09'),
(67, 27, 212, 1, '2015-01-09'),
(68, 16, 212, 0.8, '2015-01-09'),
(69, 43, 212, 27, '2015-01-09'),
(70, 41, 212, 203, '2015-01-09'),
(71, 42, 212, 202, '2015-01-09'),
(72, 27, 213, 1, '2015-01-09'),
(73, 16, 213, 0.66, '2015-01-09'),
(74, 43, 213, 28, '2015-01-09'),
(75, 41, 213, 203, '2015-01-09'),
(76, 42, 213, 202, '2015-01-09'),
(77, 27, 214, 1, '2015-01-09'),
(78, 16, 214, 0.65, '2015-01-09'),
(79, 43, 214, 28, '2015-01-09'),
(80, 41, 214, 203, '2015-01-09'),
(81, 42, 214, 202, '2015-01-09'),
(82, 16, 215, 0, '2015-01-09'),
(83, 42, 215, 0, '2015-01-09'),
(84, 41, 215, 0, '2015-01-09'),
(85, 40, 213, 0, '2015-01-09'),
(86, 36, 213, 0, '2015-01-09');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_option`
--

DROP TABLE IF EXISTS `product_attribute_value_option`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_option` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `updated_date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_attribute_value_option`
--

INSERT INTO `product_attribute_value_option` (`id`, `attribute_id`, `product_id`, `value`, `updated_date`) VALUES
(1, 25, 202, 11, '2015-01-09'),
(2, 38, 202, 17, '2015-01-09'),
(3, 39, 202, 18, '2015-01-09'),
(4, 44, 202, 22, '2015-01-09'),
(5, 46, 202, 24, '2015-01-09'),
(6, 25, 203, 12, '2015-01-09'),
(7, 38, 203, 16, '2015-01-09'),
(8, 39, 203, 18, '2015-01-09'),
(9, 44, 203, 22, '2015-01-09'),
(10, 46, 203, 26, '2015-01-09'),
(11, 25, 204, 12, '2015-01-09'),
(12, 38, 204, 17, '2015-01-09'),
(13, 39, 204, 18, '2015-01-09'),
(14, 44, 204, 22, '2015-01-09'),
(15, 46, 204, 25, '2015-01-09'),
(16, 25, 205, 12, '2015-01-09'),
(17, 38, 205, 17, '2015-01-09'),
(18, 39, 205, 18, '2015-01-09'),
(19, 44, 205, 22, '2015-01-09'),
(20, 46, 205, 25, '2015-01-09'),
(21, 25, 206, 11, '2015-01-09'),
(22, 38, 206, 16, '2015-01-09'),
(23, 39, 206, 18, '2015-01-09'),
(24, 44, 206, 22, '2015-01-09'),
(25, 46, 206, 24, '2015-01-09'),
(26, 25, 207, 12, '2015-01-09'),
(27, 38, 207, 16, '2015-01-09'),
(28, 39, 207, 18, '2015-01-09'),
(29, 44, 207, 22, '2015-01-09'),
(30, 46, 207, 24, '2015-01-09'),
(31, 25, 208, 12, '2015-01-09'),
(32, 38, 208, 16, '2015-01-09'),
(33, 39, 208, 18, '2015-01-09'),
(34, 44, 208, 22, '2015-01-09'),
(35, 46, 208, 25, '2015-01-09'),
(37, 25, 209, 11, '2015-01-09'),
(38, 44, 209, 23, '2015-01-09'),
(39, 25, 210, 12, '2015-01-09'),
(40, 44, 210, 23, '2015-01-09'),
(41, 38, 209, 16, '2015-01-09'),
(42, 39, 209, 18, '2015-01-09'),
(43, 46, 209, 24, '2015-01-09'),
(44, 25, 211, 12, '2015-01-09'),
(45, 44, 211, 23, '2015-01-09'),
(46, 25, 212, 11, '2015-01-09'),
(47, 44, 212, 23, '2015-01-09'),
(48, 37, 203, 15, '2015-01-09'),
(49, 25, 213, 11, '2015-01-09'),
(50, 46, 213, 24, '2015-01-09'),
(51, 44, 213, 23, '2015-01-09'),
(52, 25, 214, 12, '2015-01-09'),
(53, 46, 214, 25, '2015-01-09'),
(54, 44, 214, 23, '2015-01-09'),
(55, 38, 213, 16, '2015-01-09'),
(56, 39, 213, 18, '2015-01-09');

-- --------------------------------------------------------

--
-- Table structure for table `product_attribute_value_text`
--

DROP TABLE IF EXISTS `product_attribute_value_text`;
CREATE TABLE IF NOT EXISTS `product_attribute_value_text` (
`id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `updated_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE IF NOT EXISTS `product_category` (
`id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id`, `product_id`, `category_id`, `sort_order`) VALUES
(1, 3, 2, 0),
(2, 3, 3, 0),
(3, 4, 2, 0),
(4, 5, 2, 0),
(5, 5, 3, 0),
(6, 6, 2, 0),
(7, 6, 3, 0),
(8, 7, 2, 0),
(9, 7, 3, 0),
(10, 8, 3, 0),
(25, 17, 3, 0),
(30, 16, 3, 0),
(32, 19, 3, 0),
(49, 21, 4, 0),
(50, 23, 5, 0),
(51, 24, 4, 0),
(52, 25, 4, 0),
(53, 26, 4, 0),
(54, 27, 4, 0),
(57, 32, 4, 0),
(58, 33, 4, 0),
(59, 34, 4, 0),
(60, 11, 4, 0),
(61, 31, 4, 0),
(62, 30, 4, 0),
(63, 29, 4, 0),
(64, 28, 4, 0),
(65, 20, 4, 0),
(66, 18, 4, 0),
(67, 15, 4, 0),
(68, 14, 4, 0),
(70, 13, 4, 0),
(71, 12, 4, 0),
(72, 35, 4, 0),
(73, 36, 4, 0),
(74, 37, 4, 0),
(75, 38, 4, 0),
(76, 41, 4, 0),
(77, 42, 4, 0),
(78, 43, 4, 0),
(79, 44, 4, 0),
(80, 45, 4, 0),
(81, 46, 4, 0),
(82, 47, 4, 0),
(83, 48, 4, 0),
(84, 49, 4, 0),
(85, 56, 4, 0),
(86, 57, 4, 0),
(91, 62, 4, 0),
(92, 73, 4, 0),
(93, 75, 4, 0),
(94, 77, 4, 0),
(95, 78, 4, 0),
(97, 79, 4, 0),
(98, 80, 4, 0),
(99, 81, 4, 0),
(100, 82, 4, 0),
(101, 83, 4, 0),
(102, 84, 4, 0),
(103, 85, 4, 0),
(104, 86, 4, 0),
(105, 87, 4, 0),
(106, 88, 4, 0),
(107, 89, 4, 0),
(108, 90, 4, 0),
(109, 95, 4, 0),
(110, 96, 4, 0),
(111, 97, 4, 0),
(112, 98, 4, 0),
(113, 99, 4, 0),
(114, 100, 4, 0),
(115, 101, 4, 0),
(116, 102, 4, 0),
(117, 103, 4, 0),
(118, 104, 4, 0),
(119, 105, 4, 0),
(120, 106, 4, 0),
(121, 107, 4, 0),
(122, 108, 4, 0),
(123, 109, 4, 0),
(124, 110, 4, 0),
(125, 111, 4, 0),
(126, 112, 4, 0),
(127, 113, 4, 0),
(128, 114, 4, 0),
(129, 115, 4, 0),
(131, 116, 4, 0),
(132, 117, 4, 0),
(133, 118, 4, 0),
(134, 119, 4, 0),
(135, 120, 4, 0),
(136, 121, 4, 0),
(137, 122, 4, 0),
(138, 123, 4, 0),
(139, 124, 4, 0),
(143, 128, 4, 0),
(144, 129, 4, 0),
(145, 130, 4, 0),
(146, 131, 4, 0),
(147, 132, 4, 0),
(148, 133, 4, 0),
(149, 134, 4, 0),
(150, 135, 4, 0),
(151, 136, 4, 0),
(152, 137, 4, 0),
(153, 138, 4, 0),
(154, 139, 4, 0),
(155, 140, 4, 0),
(156, 141, 4, 0),
(157, 142, 4, 0),
(158, 143, 4, 0),
(159, 144, 4, 0),
(160, 145, 4, 0),
(161, 146, 4, 0),
(162, 147, 4, 0),
(163, 148, 4, 0),
(164, 149, 4, 0),
(165, 150, 4, 0),
(166, 151, 4, 0),
(167, 152, 4, 0),
(168, 153, 4, 0),
(169, 154, 4, 0),
(170, 155, 4, 0),
(171, 156, 4, 0),
(172, 157, 4, 0),
(173, 158, 4, 0),
(174, 159, 4, 0),
(175, 160, 4, 0),
(176, 161, 4, 0),
(177, 162, 4, 0),
(178, 163, 4, 0),
(179, 164, 4, 0),
(180, 165, 4, 0),
(181, 166, 4, 0),
(186, 125, 4, 0),
(187, 126, 4, 0),
(188, 127, 4, 0),
(189, 167, 4, 0),
(190, 168, 4, 0),
(191, 169, 4, 0),
(192, 170, 4, 0),
(193, 171, 4, 0),
(194, 172, 4, 0),
(195, 173, 4, 0),
(196, 174, 4, 0),
(197, 175, 4, 0),
(198, 176, 4, 0),
(199, 177, 4, 0),
(200, 178, 4, 0),
(201, 179, 4, 0),
(202, 180, 4, 0),
(203, 181, 4, 0),
(205, 183, 4, 0),
(208, 186, 4, 0),
(218, 58, 4, 0),
(219, 59, 4, 0),
(220, 60, 4, 0),
(221, 61, 4, 0),
(222, 182, 4, 0),
(223, 184, 4, 0),
(224, 185, 4, 0),
(225, 188, 4, 0),
(226, 189, 4, 0),
(227, 190, 4, 0),
(228, 191, 4, 0),
(229, 192, 4, 0),
(230, 193, 4, 0),
(231, 194, 4, 0),
(232, 195, 4, 0),
(233, 196, 4, 0),
(234, 197, 4, 0),
(236, 187, 3, 0),
(237, 199, 4, 0),
(238, 200, 4, 0),
(239, 201, 4, 0),
(240, 202, 4, 0),
(246, 203, 4, 0),
(248, 206, 4, 0),
(249, 207, 4, 0),
(251, 204, 4, 0),
(253, 210, 4, 0),
(254, 209, 4, 0),
(255, 211, 4, 0),
(256, 212, 4, 0),
(258, 214, 4, 0),
(261, 208, 4, 0),
(265, 213, 4, 0),
(266, 215, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder_product`
--

DROP TABLE IF EXISTS `purchaseorder_product`;
CREATE TABLE IF NOT EXISTS `purchaseorder_product` (
`id` int(11) NOT NULL,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_sku` varchar(255) DEFAULT NULL,
  `unit_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseorder_product`
--

INSERT INTO `purchaseorder_product` (`id`, `purchase_order_id`, `product_id`, `product_name`, `product_sku`, `unit_price`, `quantity`, `total_price`) VALUES
(12, 10, 16, 'Grass', 'grass', 100, 10, 1000),
(13, 10, 187, 'Hay', 'hay', 100, 100, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE IF NOT EXISTS `purchase_orders` (
`purchase_order_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `purchase_order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purchase_order_recieve_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `purchase_order_assigned_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`purchase_order_id`, `employee_id`, `purchase_order_date`, `purchase_order_recieve_date`, `purchase_order_assigned_date`) VALUES
(10, 0, '2015-01-06 18:15:00', '2015-01-06 18:15:00', '2015-01-06 18:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `rabbit_daily_feeds`
--

DROP TABLE IF EXISTS `rabbit_daily_feeds`;
CREATE TABLE IF NOT EXISTS `rabbit_daily_feeds` (
`daily_feed_id` int(11) NOT NULL,
  `feeding_group_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `weight_group_id` int(11) NOT NULL,
  `quantity` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rabbit_daily_feeds`
--

INSERT INTO `rabbit_daily_feeds` (`daily_feed_id`, `feeding_group_id`, `product_id`, `weight_group_id`, `quantity`) VALUES
(1, 24, 215, 1, 0),
(2, 24, 215, 2, 0),
(3, 24, 215, 3, 56),
(4, 24, 215, 4, 78),
(5, 24, 215, 5, 100),
(6, 24, 215, 6, 122),
(7, 25, 215, 1, 0),
(8, 25, 215, 2, 0),
(9, 25, 215, 3, 55.5),
(10, 25, 215, 4, 77.7),
(11, 25, 215, 5, 100),
(12, 25, 215, 6, 122.2),
(13, 26, 215, 1, 0),
(14, 26, 215, 2, 0),
(15, 26, 215, 3, 83.25),
(16, 26, 215, 4, 116.5),
(17, 26, 215, 5, 150),
(18, 26, 215, 6, 183.15),
(19, 27, 215, 1, 62.5),
(20, 27, 215, 2, 144.15),
(21, 27, 215, 3, 240.25),
(22, 27, 215, 4, 0),
(23, 27, 215, 5, 0),
(24, 27, 215, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `rabbit_litters`
--

DROP TABLE IF EXISTS `rabbit_litters`;
CREATE TABLE IF NOT EXISTS `rabbit_litters` (
`litter_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `parent_buck_id` int(11) DEFAULT NULL,
  `family_id` int(11) NOT NULL,
  `litter_group_id` int(11) DEFAULT NULL,
  `litters_dob` date NOT NULL,
  `litters_weaning_date` date NOT NULL,
  `litter_weight` float DEFAULT NULL,
  `updated_date` date NOT NULL,
  `rabbit_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rabbit_litters`
--

INSERT INTO `rabbit_litters` (`litter_id`, `parent_id`, `parent_buck_id`, `family_id`, `litter_group_id`, `litters_dob`, `litters_weaning_date`, `litter_weight`, `updated_date`, `rabbit_id`) VALUES
(19, 203, 202, 1, 28, '2015-01-09', '2015-01-09', 0.5, '2015-01-09', 213),
(20, 203, 202, 1, 28, '2015-01-09', '2015-01-09', 0.65, '2015-01-09', 214),
(21, 203, 202, 1, 28, '2015-01-09', '0000-00-00', 0.7, '2015-01-09', NULL),
(22, 203, 202, 1, 28, '2015-01-09', '0000-00-00', 0.55, '2015-01-09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rabbit_weight_group`
--

DROP TABLE IF EXISTS `rabbit_weight_group`;
CREATE TABLE IF NOT EXISTS `rabbit_weight_group` (
`id` int(11) NOT NULL,
  `min_weight` float NOT NULL,
  `max_weight` float DEFAULT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rabbit_weight_group`
--

INSERT INTO `rabbit_weight_group` (`id`, `min_weight`, `max_weight`, `name`) VALUES
(1, 0.6, 0.7, '0.6 - 0.7 kg'),
(2, 1, 2, '1 kg - 2 kg'),
(3, 2, 3, '2 kg - 3 kg'),
(4, 3, 4, '3 kg - 4 kg'),
(5, 4, 5, '4 kg - 5 kg'),
(6, 5, NULL, '5+ kg');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
`sid` bigint(20) NOT NULL,
  `product_id` bigint(100) NOT NULL,
  `Quantity` bigint(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`sid`, `product_id`, `Quantity`, `date`) VALUES
(23, 16, 23, '2015-01-08'),
(24, 127, 5, '2015-01-08'),
(26, 187, 0, '2015-01-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aa_death`
--
ALTER TABLE `aa_death`
 ADD PRIMARY KEY (`d_id`), ADD UNIQUE KEY `rid` (`rid`), ADD UNIQUE KEY `lid` (`lid`);

--
-- Indexes for table `aa_family`
--
ALTER TABLE `aa_family`
 ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `aa_family_to_be`
--
ALTER TABLE `aa_family_to_be`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `aa_litter`
--
ALTER TABLE `aa_litter`
 ADD PRIMARY KEY (`l_id`), ADD KEY `f_id` (`f_id`);

--
-- Indexes for table `aa_rabbits`
--
ALTER TABLE `aa_rabbits`
 ADD PRIMARY KEY (`r_id`), ADD UNIQUE KEY `rabbit_slug` (`rabbit_slug`), ADD KEY `l_id` (`l_id`,`f_id`), ADD KEY `f_id` (`f_id`);

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
 ADD PRIMARY KEY (`attribute_id`), ADD UNIQUE KEY `attribute_code` (`attribute_code`);

--
-- Indexes for table `attribute_attributeset`
--
ALTER TABLE `attribute_attributeset`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`,`attribute_set_id`), ADD KEY `attribute_set_id` (`attribute_set_id`);

--
-- Indexes for table `attribute_sets`
--
ALTER TABLE `attribute_sets`
 ADD PRIMARY KEY (`attribute_set_id`);

--
-- Indexes for table `attribute_values`
--
ALTER TABLE `attribute_values`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`category_id`), ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `products_inventory`
--
ALTER TABLE `products_inventory`
 ADD PRIMARY KEY (`product_id`), ADD KEY `product_type_id` (`product_type_id`,`attribute_set_id`), ADD KEY `attribute_set_id` (`attribute_set_id`);

--
-- Indexes for table `products_type`
--
ALTER TABLE `products_type`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `product_type_code` (`product_type_code`);

--
-- Indexes for table `product_attribute_value_date`
--
ALTER TABLE `product_attribute_value_date`
 ADD PRIMARY KEY (`id`), ADD KEY `product_id` (`product_id`), ADD KEY `product_id_2` (`product_id`);

--
-- Indexes for table `product_attribute_value_number`
--
ALTER TABLE `product_attribute_value_number`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`,`product_id`), ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product_attribute_value_option`
--
ALTER TABLE `product_attribute_value_option`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`), ADD KEY `product_id` (`product_id`), ADD KEY `value_id` (`value`);

--
-- Indexes for table `product_attribute_value_text`
--
ALTER TABLE `product_attribute_value_text`
 ADD PRIMARY KEY (`id`), ADD KEY `attribute_id` (`attribute_id`,`product_id`), ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
 ADD PRIMARY KEY (`id`), ADD KEY `product_id` (`product_id`,`category_id`), ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `purchaseorder_product`
--
ALTER TABLE `purchaseorder_product`
 ADD PRIMARY KEY (`id`), ADD KEY `purchase_order_id` (`purchase_order_id`,`product_id`), ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
 ADD PRIMARY KEY (`purchase_order_id`);

--
-- Indexes for table `rabbit_daily_feeds`
--
ALTER TABLE `rabbit_daily_feeds`
 ADD PRIMARY KEY (`daily_feed_id`), ADD KEY `product_id` (`product_id`), ADD KEY `weight_group_id` (`weight_group_id`);

--
-- Indexes for table `rabbit_litters`
--
ALTER TABLE `rabbit_litters`
 ADD PRIMARY KEY (`litter_id`);

--
-- Indexes for table `rabbit_weight_group`
--
ALTER TABLE `rabbit_weight_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
 ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aa_death`
--
ALTER TABLE `aa_death`
MODIFY `d_id` bigint(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `aa_family`
--
ALTER TABLE `aa_family`
MODIFY `f_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `aa_family_to_be`
--
ALTER TABLE `aa_family_to_be`
MODIFY `ID` bigint(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `aa_litter`
--
ALTER TABLE `aa_litter`
MODIFY `l_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `aa_rabbits`
--
ALTER TABLE `aa_rabbits`
MODIFY `r_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=209;
--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `attribute_attributeset`
--
ALTER TABLE `attribute_attributeset`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `attribute_sets`
--
ALTER TABLE `attribute_sets`
MODIFY `attribute_set_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `attribute_values`
--
ALTER TABLE `attribute_values`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `products_inventory`
--
ALTER TABLE `products_inventory`
MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=216;
--
-- AUTO_INCREMENT for table `products_type`
--
ALTER TABLE `products_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product_attribute_value_date`
--
ALTER TABLE `product_attribute_value_date`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `product_attribute_value_number`
--
ALTER TABLE `product_attribute_value_number`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `product_attribute_value_option`
--
ALTER TABLE `product_attribute_value_option`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `product_attribute_value_text`
--
ALTER TABLE `product_attribute_value_text`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=267;
--
-- AUTO_INCREMENT for table `purchaseorder_product`
--
ALTER TABLE `purchaseorder_product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
MODIFY `purchase_order_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `rabbit_daily_feeds`
--
ALTER TABLE `rabbit_daily_feeds`
MODIFY `daily_feed_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `rabbit_litters`
--
ALTER TABLE `rabbit_litters`
MODIFY `litter_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `rabbit_weight_group`
--
ALTER TABLE `rabbit_weight_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
MODIFY `sid` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `aa_litter`
--
ALTER TABLE `aa_litter`
ADD CONSTRAINT `aa_litter_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `aa_family` (`f_id`);

--
-- Constraints for table `aa_rabbits`
--
ALTER TABLE `aa_rabbits`
ADD CONSTRAINT `aa_rabbits_ibfk_1` FOREIGN KEY (`l_id`) REFERENCES `aa_litter` (`l_id`),
ADD CONSTRAINT `aa_rabbits_ibfk_2` FOREIGN KEY (`f_id`) REFERENCES `aa_family` (`f_id`);

--
-- Constraints for table `attribute_attributeset`
--
ALTER TABLE `attribute_attributeset`
ADD CONSTRAINT `attribute_attributeset_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `attribute_attributeset_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_values`
--
ALTER TABLE `attribute_values`
ADD CONSTRAINT `attribute_values_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products_inventory`
--
ALTER TABLE `products_inventory`
ADD CONSTRAINT `products_inventory_ibfk_1` FOREIGN KEY (`product_type_id`) REFERENCES `products_type` (`id`),
ADD CONSTRAINT `products_inventory_ibfk_2` FOREIGN KEY (`attribute_set_id`) REFERENCES `attribute_sets` (`attribute_set_id`);

--
-- Constraints for table `product_attribute_value_number`
--
ALTER TABLE `product_attribute_value_number`
ADD CONSTRAINT `product_attribute_value_number_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `product_attribute_value_number_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_attribute_value_option`
--
ALTER TABLE `product_attribute_value_option`
ADD CONSTRAINT `product_attribute_value_option_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `product_attribute_value_option_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `product_attribute_value_option_ibfk_3` FOREIGN KEY (`value`) REFERENCES `attribute_values` (`id`);

--
-- Constraints for table `product_attribute_value_text`
--
ALTER TABLE `product_attribute_value_text`
ADD CONSTRAINT `product_attribute_value_text_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `product_attribute_value_text_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_category`
--
ALTER TABLE `product_category`
ADD CONSTRAINT `product_category_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `product_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchaseorder_product`
--
ALTER TABLE `purchaseorder_product`
ADD CONSTRAINT `purchaseorder_product_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`purchase_order_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `purchaseorder_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`);

--
-- Constraints for table `rabbit_daily_feeds`
--
ALTER TABLE `rabbit_daily_feeds`
ADD CONSTRAINT `rabbit_daily_feeds_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products_inventory` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `rabbit_daily_feeds_ibfk_2` FOREIGN KEY (`weight_group_id`) REFERENCES `rabbit_weight_group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
